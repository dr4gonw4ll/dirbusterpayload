"""
This package contains privilege escalation methods based on enumeration facts.

This could be passwords that the enumeration module found, or private keys or
anything else of use. This is just an organizational module. Nothing special
happens here compared to other privesc modules. It just helps me keep the
different methods straight.

"""
