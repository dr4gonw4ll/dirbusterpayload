#!/usr/bin/env python3

from pwncat.remote.service import RemoteService, service_map
from pwncat.remote.victim import Victim
