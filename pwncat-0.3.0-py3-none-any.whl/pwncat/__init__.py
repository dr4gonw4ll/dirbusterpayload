#!/usr/bin/env python3
from typing import Optional

from pwncat import db

victim: Optional["pwncat.remote.Victim"] = None
